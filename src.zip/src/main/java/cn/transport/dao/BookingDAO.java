package cn.transport.dao;

import cn.transport.ctb.connection.ConnectionDB;
import cn.transport.model.Booking;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BookingDAO {
    private Connection con;

    public BookingDAO() throws ClassNotFoundException, SQLException {
        this.con = ConnectionDB.getCon();
    }

    // Create a new booking
    public int addBooking(Booking booking) throws SQLException {
        String sql = "INSERT INTO bookings (vehicle_id, pickup_location, drop_location, pickup_time, booking_date, customer_name, contact_no) "
                   + "VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement pstmt = con.prepareStatement(sql)) {
            pstmt.setInt(1, booking.getVehicleId());
            pstmt.setString(2, booking.getPickupLocation());
            pstmt.setString(3, booking.getDropLocation());
            pstmt.setString(4, booking.getPickupTime());
            pstmt.setString(5, booking.getBookingDate());
            pstmt.setString(6, booking.getCustomerName());
            pstmt.setString(7, booking.getContactNo());

            return pstmt.executeUpdate();
        }
    }

    // Read all bookings
    public List<Booking> getAllBookings() throws SQLException {
        List<Booking> bookings = new ArrayList<>();
        String sql = "SELECT * FROM bookings";

        try (Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Booking booking = new Booking();
                booking.setBookingId(rs.getInt("booking_id"));
                booking.setVehicleId(rs.getInt("vehicle_id"));
                booking.setPickupLocation(rs.getString("pickup_location"));
                booking.setDropLocation(rs.getString("drop_location"));
                booking.setPickupTime(rs.getString("pickup_time"));
                booking.setBookingDate(rs.getString("booking_date"));
                booking.setCustomerName(rs.getString("customer_name"));
                booking.setContactNo(rs.getString("contact_no"));
                bookings.add(booking);
            }
        }

        return bookings;
    }

    // Update a booking
    public int updateBooking(Booking booking) throws SQLException {
        String sql = "UPDATE bookings SET vehicle_id=?, pickup_location=?, drop_location=?, pickup_time=?, booking_date=?, customer_name=?, contact_no=? WHERE booking_id=?";

        try (PreparedStatement pstmt = con.prepareStatement(sql)) {
            pstmt.setInt(1, booking.getVehicleId());
            pstmt.setString(2, booking.getPickupLocation());
            pstmt.setString(3, booking.getDropLocation());
            pstmt.setString(4, booking.getPickupTime());
            pstmt.setString(5, booking.getBookingDate());
            pstmt.setString(6, booking.getCustomerName());
            pstmt.setString(7, booking.getContactNo());
            pstmt.setInt(8, booking.getBookingId());

            return pstmt.executeUpdate();
        }
    }

    // Delete a booking
    public int deleteBooking(int bookingId) throws SQLException {
        String sql = "DELETE FROM bookings WHERE booking_id=?";

        try (PreparedStatement pstmt = con.prepareStatement(sql)) {
            pstmt.setInt(1, bookingId);
            return pstmt.executeUpdate();
        }
    }
}

