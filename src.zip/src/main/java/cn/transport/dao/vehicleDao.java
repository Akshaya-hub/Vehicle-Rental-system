package cn.transport.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import cn.transport.model.Vehicle;
//import cn.transport.model.cart;

public class vehicleDao {
    private Connection con;
    private String query;
    private PreparedStatement pst;
    private ResultSet rs;

    public vehicleDao(Connection con) {
        this.con = con;
    }

 // Method to get a vehicle by its ID
    public Vehicle getVehicleById(int vehicleId) throws SQLException {
        Vehicle vehicle = null;
        String sql = "SELECT * FROM vehicles WHERE id = ?";
        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setInt(1, vehicleId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                vehicle = new Vehicle();
                vehicle.setId(rs.getInt("id")); // Set the ID field
                vehicle.setVehicleType(rs.getString("vehicleType"));
                vehicle.setVehicleNumber(rs.getString("vehicleNumber"));
                vehicle.setDriverName(rs.getString("driverName"));
                vehicle.setDriverContact(rs.getString("driverContact"));
                vehicle.setMaxSeats(rs.getInt("maxSeats"));
                vehicle.setSuitcaseCapacity(rs.getInt("suitcaseCapacity"));
                vehicle.setImage(rs.getString("image"));
            }
        }
        return vehicle;
    }

    // Add a new vehicle
    public void addVehicle(Vehicle vehicle) {
        try {
            String query = "INSERT INTO vehicles (id, vehicleType, vehicleNumber, driverName, driverContact, maxSeats, suitcaseCapacity, image) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            try (PreparedStatement pstmt = con.prepareStatement(query)) {
                pstmt.setInt(1, vehicle.getId());
                pstmt.setString(2, vehicle.getVehicleType());
                pstmt.setString(3, vehicle.getVehicleNumber());
                pstmt.setString(4, vehicle.getDriverName());
                pstmt.setString(5, vehicle.getDriverContact());
                pstmt.setInt(6, vehicle.getMaxSeats());
                pstmt.setInt(7, vehicle.getSuitcaseCapacity());
                pstmt.setString(8, vehicle.getImage());
                
                pstmt.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

 //  update vehicle details
    public void updateVehicle(Vehicle vehicle) throws SQLException {
        String sql = "UPDATE vehicles SET vehicleType = ?, vehicleNumber = ?, driverName = ?, driverContact = ?, maxSeats = ?, suitcaseCapacity = ?, image = ? WHERE id = ?";
        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setString(1, vehicle.getVehicleType());
            stmt.setString(2, vehicle.getVehicleNumber());
            stmt.setString(3, vehicle.getDriverName());
            stmt.setString(4, vehicle.getDriverContact());
            stmt.setInt(5, vehicle.getMaxSeats());
            stmt.setInt(6, vehicle.getSuitcaseCapacity());
            stmt.setString(7, vehicle.getImage());
            stmt.setInt(8, vehicle.getId()); // Ensure to set the vehicle ID here
            stmt.executeUpdate();
        }
    }
 // Method to retrieve all vehicles
    public List<Vehicle> getAllVehicles() throws SQLException {
        List<Vehicle> vehicles = new ArrayList<>();
        String sql = "SELECT * FROM vehicles";  // Adjust table name as needed

        try (PreparedStatement stmt = con.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Vehicle vehicle = new Vehicle();
                vehicle.setId(rs.getInt("id")); // Set the ID field
                vehicle.setVehicleType(rs.getString("vehicleType"));
                vehicle.setVehicleNumber(rs.getString("vehicleNumber"));
                vehicle.setDriverName(rs.getString("driverName"));
                vehicle.setDriverContact(rs.getString("driverContact"));
                vehicle.setMaxSeats(rs.getInt("maxSeats"));
                vehicle.setSuitcaseCapacity(rs.getInt("suitcaseCapacity"));
                vehicle.setImage(rs.getString("image"));
                vehicles.add(vehicle);
            }
        }
        return vehicles;
    }

    // Delete vehicle by ID
    public boolean deleteVehicle(int id) throws SQLException {
        boolean result = false;
        try {
            String query = "DELETE FROM vehicles WHERE id=?";
            pst = this.con.prepareStatement(query);
            pst.setInt(1, id);
            result = pst.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        }
        return result;
    }

	public void closeConnection() {
		if (con != null) {
            try {
                con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
		
	}
}
