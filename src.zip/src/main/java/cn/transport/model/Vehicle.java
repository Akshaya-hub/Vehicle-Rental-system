package cn.transport.model;

public class Vehicle {
    private int id;
    private String vehicleType;
    private String vehicleNumber;
    private String driverName;
    private String driverContact;
    private int maxSeats;
    private int suitcaseCapacity;
    private String image;

    // Constructor with parameters
    public Vehicle(int id, String vehicleType, String vehicleNumber, String driverName, String driverContact, int maxSeats, int suitcaseCapacity, String image) {
        super();
        this.id = id;
        this.vehicleType = vehicleType;
        this.vehicleNumber = vehicleNumber;
        this.driverName = driverName;
        this.driverContact = driverContact;
        this.maxSeats = maxSeats;
        this.suitcaseCapacity = suitcaseCapacity;
        this.image = image;
    }

    // Default constructor
    public Vehicle() {
        
    }

    // Getter and setter methods
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(String vehicleType) {
        this.vehicleType = vehicleType;
    }

    public String getVehicleNumber() {
        return vehicleNumber;
    }

    public void setVehicleNumber(String vehicleNumber) {
        this.vehicleNumber = vehicleNumber;
    }

    public String getDriverName() {
        return driverName;
    }

    public void setDriverName(String driverName) {
        this.driverName = driverName;
    }

    public String getDriverContact() {
        return driverContact;
    }

    public void setDriverContact(String driverContact) {
        this.driverContact = driverContact;
    }

    public int getMaxSeats() {
        return maxSeats;
    }

    public void setMaxSeats(int maxSeats) {
        this.maxSeats = maxSeats;
    }

    public int getSuitcaseCapacity() {
        return suitcaseCapacity;
    }

    public void setSuitcaseCapacity(int suitcaseCapacity) {
        this.suitcaseCapacity = suitcaseCapacity;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}

