package cn.transport.servlet;

import cn.transport.dao.BookingDAO;
import cn.transport.model.Booking;
import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/BookVehicleServlet")
public class BookVehicleServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        // Fetch parameters from the form
        String vehicleId = request.getParameter("vehicleId");
        String pickupLocation = request.getParameter("pickupLocation");
        String dropLocation = request.getParameter("dropLocation");
        String pickupTime = request.getParameter("pickupTime");
        String bookingDate = request.getParameter("bookingDate");
        String customerName = request.getParameter("customerName");
        String contactNo = request.getParameter("contactNo");

        // Create Booking object and set the values
        Booking booking = new Booking();
        booking.setVehicleId(Integer.parseInt(vehicleId));
        booking.setPickupLocation(pickupLocation);
        booking.setDropLocation(dropLocation);
        booking.setPickupTime(pickupTime);
        booking.setBookingDate(bookingDate);
        booking.setCustomerName(customerName);
        booking.setContactNo(contactNo);

        try {
            // Use BookingDAO to insert the booking into the database
            BookingDAO bookingDAO = new BookingDAO();
            int result = bookingDAO.addBooking(booking);

            // Redirect based on the result of the booking
            if (result > 0) {
                response.sendRedirect("index.jsp");
            } else {
                response.sendRedirect("index.jsp");
            }

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            response.sendRedirect("bookingError.jsp");
        }
    }
}
