package cn.transport.servlet;

import cn.transport.dao.BookingDAO;
import cn.transport.model.Booking;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ReadBookingServlet")
public class ReadBookingServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        try {
            // Fetch all bookings from the database using BookingDAO
            BookingDAO bookingDAO = new BookingDAO();
            List<Booking> bookings = bookingDAO.getAllBookings();

            // Set bookings as request attribute to forward to the JSP
            request.setAttribute("bookings", bookings);

            // Forward the request to the JSP for displaying bookings
            request.getRequestDispatcher("displayBookings.jsp").forward(request, response);

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            response.sendRedirect("bookingError.jsp");  // Handle error page if needed
        }
    }
}
