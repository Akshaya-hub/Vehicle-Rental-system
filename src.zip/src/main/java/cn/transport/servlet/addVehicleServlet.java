package cn.transport.servlet;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import cn.transport.ctb.connection.ConnectionDB;
import cn.transport.dao.vehicleDao;
import cn.transport.model.Vehicle;

@WebServlet("/AddVehicleServlet")
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2, // 2MB
                 maxFileSize = 1024 * 1024 * 10,      // 10MB
                 maxRequestSize = 1024 * 1024 * 50)   // 50MB
public class addVehicleServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private static final String SAVE_DIR = "vehicle-images";  // Use the same directory in both servlets

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Retrieve form parameters
        String vehicleType = request.getParameter("vehicleType");
        String vehicleNumber = request.getParameter("vehicleNumber");
        String driverName = request.getParameter("driverName");
        String driverContact = request.getParameter("driverContact");
        String maxSeatsStr = request.getParameter("maxSeats");
        String suitcaseCapacityStr = request.getParameter("suitcaseCapacity");

        // Convert maxSeats and suitcaseCapacity to int
        int maxSeats = Integer.parseInt(maxSeatsStr);
        int suitcaseCapacity = Integer.parseInt(suitcaseCapacityStr);

     // Get the application path and create directory if it doesn't exist
        String appPath = request.getServletContext().getRealPath("");
        String savePath = appPath + File.separator + SAVE_DIR;
        File fileSaveDir = new File(savePath);
        if (!fileSaveDir.exists()) {
            fileSaveDir.mkdir();  // Ensure the directory exists
        }

        // Handle file upload
        Part filePart = request.getPart("image");
        String fileName = extractFileName(filePart);
        String filePath = savePath + File.separator + fileName;
        filePart.write(filePath);  // Save the file to the directory

        // Relative file path to save in the database (for serving images later)
        String imagePath =  File.separator + fileName;

        // Create a new Vehicle object
        Vehicle vehicle = new Vehicle();
        vehicle.setVehicleType(vehicleType);
        vehicle.setVehicleNumber(vehicleNumber);
        vehicle.setDriverName(driverName);
        vehicle.setDriverContact(driverContact);
        vehicle.setMaxSeats(maxSeats);
        vehicle.setSuitcaseCapacity(suitcaseCapacity);
        vehicle.setImage(imagePath);  // Store relative path in the database

        try {
            // Create VehicleDao instance
            vehicleDao vehicleDao = new vehicleDao(ConnectionDB.getCon());

            // Call the addVehicle method to insert vehicle into the database
            vehicleDao.addVehicle(vehicle);

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            // If an exception occurs, redirect to an error page
            response.sendRedirect("error.jsp");
            return;
        }

        // Redirect back to vehicle_hub.jsp (the page where the user can view added vehicles)
        response.sendRedirect("vehicle_hub.jsp");
    }

    // Extract file name from the Part header
    private String extractFileName(Part part) {
        String contentDisp = part.getHeader("content-disposition");
        String[] items = contentDisp.split(";");
        for (String s : items) {
            if (s.trim().startsWith("filename")) {
                return s.substring(s.indexOf("=") + 2, s.length() - 1);
            }
        }
        return "";
    }
}
