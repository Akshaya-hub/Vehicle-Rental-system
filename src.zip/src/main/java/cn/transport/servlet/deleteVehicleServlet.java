package cn.transport.servlet;

import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.transport.ctb.connection.ConnectionDB;
import cn.transport.dao.vehicleDao;

@WebServlet("/DeleteVehicleServlet")
public class deleteVehicleServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String vehicleIdStr = request.getParameter("id");

        try {
            int vehicleId = Integer.parseInt(vehicleIdStr);
            vehicleDao vehicleDao = new vehicleDao(ConnectionDB.getCon());
            vehicleDao.deleteVehicle(vehicleId);

        } catch (NumberFormatException | ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp");
            return;
        }

        response.sendRedirect("vehicle_hub.jsp");
    }
}
