package cn.transport.servlet;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import cn.transport.ctb.connection.ConnectionDB;
import cn.transport.dao.vehicleDao;
import cn.transport.model.Vehicle;

@WebServlet("/editVehicleServlet")
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2,  // 2MB
                 maxFileSize = 1024 * 1024 * 10,       // 10MB
                 maxRequestSize = 1024 * 1024 * 50)    // 50MB
public class editVehicleServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private static final String SAVE_DIR = "vehicle-images";  // Use the same directory in both servlets


    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve vehicleId from the request
        int vehicleId = Integer.parseInt(request.getParameter("vehicleId"));
        
        try {
            vehicleDao vehicleDao = new vehicleDao(ConnectionDB.getCon());
            Vehicle vehicle = vehicleDao.getVehicleById(vehicleId);
            request.setAttribute("vehicle", vehicle);
            request.getRequestDispatcher("edit_vehicle.jsp").forward(request, response);
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp");
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            // Retrieve vehicleId from the request
            int vehicleId = Integer.parseInt(request.getParameter("vehicleId"));

            // Fetch the existing vehicle details from the database
            vehicleDao vehicleDao = new vehicleDao(ConnectionDB.getCon());
            Vehicle vehicle = vehicleDao.getVehicleById(vehicleId);

            // Update the vehicle object with new values
            String vehicleType = request.getParameter("vehicleType");
            if (vehicleType != null && !vehicleType.trim().isEmpty()) {
                vehicle.setVehicleType(vehicleType);
            }

            String vehicleNumber = request.getParameter("vehicleNumber");
            if (vehicleNumber != null && !vehicleNumber.trim().isEmpty()) {
                vehicle.setVehicleNumber(vehicleNumber);
            }

            String driverName = request.getParameter("driverName");
            if (driverName != null && !driverName.trim().isEmpty()) {
                vehicle.setDriverName(driverName);
            }

            String driverContact = request.getParameter("driverContact");
            if (driverContact != null && !driverContact.trim().isEmpty()) {
                vehicle.setDriverContact(driverContact);
            }

            String maxSeatsStr = request.getParameter("maxSeats");
            if (maxSeatsStr != null && !maxSeatsStr.trim().isEmpty()) {
                vehicle.setMaxSeats(Integer.parseInt(maxSeatsStr));
            }

            String suitcaseCapacityStr = request.getParameter("suitcaseCapacity");
            if (suitcaseCapacityStr != null && !suitcaseCapacityStr.trim().isEmpty()) {
                vehicle.setSuitcaseCapacity(Integer.parseInt(suitcaseCapacityStr));
            }

         // Handle image upload
            Part filePart = request.getPart("image");
            if (filePart != null && filePart.getSize() > 0) {
                // Path to save the new image
                String uploadPath = getServletContext().getRealPath("") + File.separator + SAVE_DIR; // Use the same save directory
                File uploadDir = new File(uploadPath);
                if (!uploadDir.exists()) {
                    uploadDir.mkdir();  // Ensure the directory exists
                }

                // Delete the old image if it exists
                String oldImageName = vehicle.getImage(); // Assuming getImage() returns the filename
                File oldImageFile = new File(uploadPath + File.separator + oldImageName);
                if (oldImageFile.exists()) {
                    oldImageFile.delete(); // Delete old image
                }

                // Upload the new image
                String newFileName = extractFileName(filePart);
                filePart.write(uploadPath + File.separator + newFileName);
                vehicle.setImage(newFileName); // Set the new image name in the vehicle object
            }

            // Set the vehicle ID in the vehicle object
            vehicle.setId(vehicleId);

            // Update the vehicle in the database
            vehicleDao.updateVehicle(vehicle);

            response.getWriter().write("success");

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp");
        }
    }

    private String extractFileName(Part part) {
        String contentDisposition = part.getHeader("content-disposition");
        String[] items = contentDisposition.split(";");
        for (String item : items) {
            if (item.trim().startsWith("filename")) {
                return item.substring(item.indexOf("=") + 2, item.length() - 1);
            }
        }
        return "";
    }
}
